# Website HMJ MPI UIN Raden Intan Lampung

Website statis untuk HMJ MPI periode 2026–2027. Dibuat dengan HTML, CSS, dan JavaScript tanpa framework sehingga dapat dipublikasikan gratis melalui GitHub Pages.

## Isi folder
- `index.html` — konten dan struktur halaman
- `style.css` — desain responsif
- `script.js` — interaksi menu versi mobile

## Sebelum dipublikasikan
Ganti konten contoh berikut di `index.html`:
1. `Nama Ketua Umum`, `Nama Sekretaris`, dan `Nama Bendahara`.
2. Tautan Instagram `https://www.instagram.com/` dengan akun resmi HMJ MPI.
3. Email resmi organisasi pada bagian kontak.
4. Kategori program kerja dengan program kerja yang telah disahkan.
5. Konten berita dan placeholder galeri dengan informasi serta foto kegiatan asli.

Logo teks MPI dapat diganti dengan file logo resmi jika tersedia. Letakkan file logo di folder ini, lalu ubah bagian `.brand-mark` pada `index.html`.

## Cara publikasi gratis dengan GitHub Pages
1. Masuk atau buat akun di https://github.com/.
2. Klik **New repository**.
3. Isi nama repository, misalnya `hmj-mpi-uin-ril`, pilih **Public**, lalu klik **Create repository**.
4. Klik **Add file → Upload files**, unggah `index.html`, `style.css`, `script.js`, dan `README.md` dari folder ini.
5. Klik **Commit changes**.
6. Buka **Settings → Pages**.
7. Pada bagian **Build and deployment**, pilih **Deploy from a branch**.
8. Pilih branch **main**, folder **/(root)**, lalu klik **Save**.
9. Tunggu proses publikasi. Alamat website akan menjadi:
   `https://USERNAME.github.io/hmj-mpi-uin-ril/`
   Ganti `USERNAME` dengan username GitHub akun pengelola.

## Pembaruan website
Untuk memperbarui isi, buka file terkait di repository GitHub, klik ikon pensil, edit, lalu klik **Commit changes**. GitHub Pages akan menerbitkan pembaruan secara otomatis setelah proses build selesai.

## Catatan
Hosting GitHub Pages gratis untuk repository publik. Alamat bawaan menggunakan subdomain `github.io`; domain khusus berbayar bersifat opsional. Jangan unggah data pribadi sensitif atau dokumen internal organisasi yang tidak ditujukan untuk publik.


## Pembaruan kepengurusan dan logo
Paket ini memuat struktur pengurus periode 2026–2027 berdasarkan SK Dekan Nomor 1 Tahun 2026. Halaman menampilkan nama dan jabatan saja, tanpa NPM. Upload/replace `index.html`, `style.css`, dan tambahkan `logo-hmj-mpi.png` ke root repository GitHub Pages. `script.js` tetap dapat menggunakan versi yang sudah ada.
